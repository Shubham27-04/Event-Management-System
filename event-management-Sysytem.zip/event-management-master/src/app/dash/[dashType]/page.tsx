import React from "react";

const Prof = () => {
  return;
};

export default Prof;

