const Denied = () => {
  return <div>Denied Access</div>;
};

export default Denied;
